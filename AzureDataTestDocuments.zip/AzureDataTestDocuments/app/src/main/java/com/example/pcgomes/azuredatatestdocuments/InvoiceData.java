package com.example.pcgomes.azuredatatestdocuments;
import java.math.BigDecimal;
import java.util.Date;

//
// Data structure for invoices
//

public class InvoiceData {

    public int id;
    public String invoiceDate;
    public String cause;
    public String valor;


}